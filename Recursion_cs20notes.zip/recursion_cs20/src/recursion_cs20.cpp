//============================================================================
// Name        : recursion_cs20.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : Recursion notes
//============================================================================

#include <iostream>
using namespace std;

	void recursive1(int x){		//recursive function
		if (x != 0){
			cout << "ticking back..." << x << endl;
			--x;
			recursive1(x);
			/*
			 * return address
			 * the argument being to the function (x)
			 * old stack frame base pointer
			 * new stack frame base pointer
			 */
		}else{
			return;
		}//else
	}//recursive1


int main() {



	recursive1(10);



	cout << "Program Ending..." << endl; // prints Recursion notes
	return 0;
}
