//============================================================================
// Name        : PointerReview2.cpp
// Author      : Andreas Zignago
// Version     : 1.00
// Copyright   : Your copyright notice, for school purposes only
// Description : Pointer review of arrays and the basics around it
//Notes: Asymptotic Analysis, looking at an function and calculating it's complexity
//pr-post conditions: what is expected before and after for the code to run
//============================================================================

#include <iostream>
#include<cstdlib>
#include<ctime>
using namespace std;

bool increaseArray(int* &arrayPtr, int oldSize, int sizeIncrease);

int main() {

	int* myIntArray = nullptr;	/*creation of initial array and size holders*/
	int arraySize = 0;
	int arraySize2 = 0;

	cout << "How large would you like to make the first array? ";
	cin >> arraySize;	/*getting first set of data*/
	myIntArray = new int[arraySize];
	for (int i=0; i<arraySize; i++) { /*creating first array*/
		myIntArray[i] = i;
	}//for

	cout << "Now printing your requested array" << endl;
	for(int i=0; i<arraySize; i++){ /*printing first array*/
		cout << myIntArray[i] << endl;
	}//for

	cout << "how much larger would you like to make your array? ";
	cin >> arraySize2; /*getting new array size*/

	if (increaseArray(myIntArray,arraySize, arraySize2)){
		cout << "Array increased successfully" << endl;
	}//if
	else{
		cout << "Array increase was not successful" << endl;
	}//else

	//function of the size increase array
	increaseArray(myIntArray, arraySize, arraySize2);

	//commenting out the for loop to remove redundancy with the function included
	//int* tempArray = new int[arraySize + arraySize2];
	//for(int i=0; i<arraySize; i++){   /*exchanging array*/
	//	tempArray[i] = myIntArray[i];
	//	myIntArray[i] = 0;
	//}//for
	//delete [] myIntArray;	/*deleting old array and replacing it with new from temp*/
	//myIntArray = tempArray;
	//arraySize += arraySize2;*/

	cout << "Now printing your updated requested array" << endl;
		for(int i=0; i<arraySize; i++){/*printing array*/
			cout << myIntArray[i] << endl;
		}//for

		for(int i=0; i<arraySize; i++){ /*zeroing out our array for security clearing*/
			myIntArray[i] = 0;
		}//for
	delete [] myIntArray;


	cout << "Program ending, good bye" << endl; // prints Pointer Review over arrays of pointers
	return 0;
}

//making the increase array size for loop into a function to be called
bool increaseArray(int* &arrayPtr, int oldSize, int sizeIncrease){
	srand(time(0)); //computer epoch 1970/01/01
	if ((oldSize + sizeIncrease) <= 0){
		return false;
	}
	else{
		int* tempArray = new int[oldSize + sizeIncrease];
		for(int i=0; i<oldSize; i++){   /*exchanging array*/
			tempArray[i] = arrayPtr[i];
			arrayPtr[i] = rand()%100;
			cout << arrayPtr[i] << endl;
		}//for
		delete [] arrayPtr;	/*deleting old array and replacing it with new from temp*/
		arrayPtr = tempArray;
		tempArray = nullptr;
		oldSize += sizeIncrease;
		return true;
	}//else
}//increaseArray
