//============================================================================
// Name        : list_multimap_notes_cs20.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : list and multimap notes from cs20, Ansi-style
//============================================================================

#include <iostream>
#include<list>
using namespace std;

struct myWidget{
	bool x;
	string y;
	int z;
};

int addTwo (int x, int y){
	return x+y;
}

bool somefunction(myWidget a, myWidget b){
	if(a.y < b.y){
		return true;
	}else{
		return false;
	}//else
}//bool somefunction


int main() {

	int someInt = 0;


	cout << " List, multi maps and maps notes for cs20" << endl;

	cout << "displaying what comes first in an increment command: "
			<< endl << addTwo(++someInt, 3) << endl
			<< addTwo(someInt++, 3) << endl;

	//auto* x = somefunction;

	//cout << somefunction << endl;
	//cout << &somefunction << endl;


	list<string> myStringList;
	list<string>::iterator myStringListIT;
	int theSize = myStringList.size();


	myStringList.push_back("Sarah");
	myStringList.push_front("Tabatha");
	myStringList.push_back("Sammy");

	cout << "Unsorted List: " << endl;
	for(myStringListIT = myStringList.begin();
			myStringListIT != myStringList.end();
			++myStringListIT){
		cout << (*myStringListIT) << endl;
	}//for


	myStringList.sort();

	cout << "Sorted List: " << endl;
	for(myStringListIT = myStringList.begin();
			myStringListIT != myStringList.end();
			++myStringListIT){
		cout << (*myStringListIT) << endl;
	}//for


	cout << "program ending, goodbye" << endl; // prints arraylistnotes
	return 0;
}
