//============================================================================
// Name        : CS20_hash.cpp
// Author      : Andreas
// Version     :
// Copyright   : school work code
// Description : This is a basic example on the logic of a
//					algorithm, where a name is entered as the key
//					and the hash value is returned.
//============================================================================

#include <iostream>
using namespace std;
int hashIt(string theString);

struct BucketArray {
	string theBucket[6];
};

int main() {
	const int SIZEOFARRAY = 100;

	BucketArray* hashTable[SIZEOFARRAY];
	for(int i =0; i<SIZEOFARRAY; i++){
		hashTable[i] = new BucketArray;
	}
	string theName;
	int hashValue = 0, hashKey = 0;
	string nameArray[SIZEOFARRAY];

	//hashValue = hashIt(theName);

	while (true) {
		cout << "Please enter your name(the key), -999 to quit: ";
		getline(cin, theName);

		if (theName == "-999") {
			cout << "exiting" << endl;
			break;
		} else {
			hashValue = hashIt(theName);
			if(hashValue == 0){
				cout << "Name to long or to short, must be 1-12 characters" << endl;
				continue;
			}else{}
			cout << "your hash value is: " << hashValue << endl;
			hashKey = hashValue%SIZEOFARRAY;
			if(nameArray[hashKey].size() !=0){
				cout << "Collision!" << endl;
			}else{
				nameArray[hashKey] = theName;
			}
		} //else
	} //while

	while (true) {
		cout << "Please enter your name to search for (the key), -999 to quit: ";
		getline(cin, theName);
		if (theName == "-999") {
			cout << "exiting" << endl;
			break;
		} else {
			hashValue = hashIt(theName);
			hashKey = hashValue%SIZEOFARRAY;
			if(nameArray[hashKey].size() == 0){
				cout << "Not found" << endl;
			}else{
				cout << "found: " << nameArray[hashKey] << endl;
			}
		} //else
	} //while
	for(int i=0; i < SIZEOFARRAY; i++){
		cout << nameArray[i] << endl;
	}
	cout << "Program ending..." << endl; // prints Program ending...
	return 0;
}//main
int hashIt(string theString) {
	int returnInt = 0;
	if(theString.size() > 12 || theString.size() < 1){
		return 0;
	}else{
	//returnInt = theString.size();
	for (unsigned int i = 0; i < theString.size(); i++) {
		returnInt += static_cast<int>(theString[i]);
	} //for
	returnInt += static_cast<int>(theString[0]);
	returnInt += static_cast<int>(theString[theString.size()-1]);
	returnInt /= 3;
	return returnInt;
	}//else
} //hashIt
