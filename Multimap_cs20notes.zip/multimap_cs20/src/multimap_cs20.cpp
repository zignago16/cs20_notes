//============================================================================
// Name        : multimap_cs20.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : Notes going over specifically multi maps, Ansi-style
//============================================================================

#include <iostream>
#include <map>
using namespace std;

class Student {
private:

public:
	string name;
	int ID;
};

int main() {
	cout << "program starting" << endl;

	multimap<int, Student*> myMultimap;
	multimap<int, Student*>::iterator myIT;
	Student *mySt = new Student;
	mySt->ID = 3;
	mySt->name = "Nic";
	myMultimap.insert(pair<int, Student*>(mySt->ID, mySt));

	mySt = new Student;
	mySt->ID = 3;
	mySt->name = "pineapple";
	myMultimap.insert(pair<int, Student*>(mySt->ID, mySt));

	mySt = new Student;
	mySt->ID = 3;
	mySt->name = "mango";
	myMultimap.insert(pair<int, Student*>(mySt->ID, mySt));

	mySt = new Student;
	mySt->ID = 13;
	mySt->name = "andreas";
	myMultimap.insert(pair<int, Student*>(mySt->ID, mySt));

	mySt = new Student;
	mySt->ID = 13;
	mySt->name = "andreas2";
	myMultimap.insert(pair<int, Student*>(mySt->ID, mySt));

	cout << "Showing Nic's records: " << myMultimap.count(3) << endl;
	cout << "Showing Andreas' records: " << myMultimap.count(13) << endl;

	//finding all the records that match a specifc key without coding the key, so search basically
	pair<multimap<int, Student*>::iterator,
		multimap<int, Student*>::iterator> rangeIT;
	rangeIT = myMultimap.equal_range(3);
	for(myIT = rangeIT.first;
			myIT != rangeIT.second;
			++myIT){
		cout << (*myIT).second->name << endl;
	}

	cout << "Program ending, good bye" << endl; // prints multi maps
	return 0;
}
