/*
 * Pasta.cpp
 *
 *  Created on: Sep 14, 2021
 *      Author: andre
 */

#include "Pasta.hpp"

Pasta::Pasta() {
	// TODO Auto-generated constructor stub

	this->calories = 0;


}

Pasta::~Pasta() {
	// TODO Auto-generated destructor stub
}

