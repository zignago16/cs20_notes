//============================================================================
// Name        : arraylistnotes.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : notes on arraylisting about data dimensions
//============================================================================
#include "Pasta.hpp"
#include <iostream>
using namespace std;

//note i did not copy the whole thing down properly

int main() {

	int intarray[10000] = { 10, 100, 200, 300 };
	cout << intarray << endl;
	int *intPtr = intarray;
	cout << *intPtr << endl;
	intPtr++;
	cout << "after the incremented data position: " << *intPtr << endl << intPtr
			<< endl;
	cout << "where it's supposed to be" << intarray[0] << endl;
	cout << "after going back to it's position" << endl;
	intPtr--;
	cout << *intPtr << endl;
	cout << intPtr << endl;

	/*while(true) {
	 * intPtr--;
	 * cout << *intPtr << endl;
	 * cout << intPtr << endl;
	 * *intPtr = 0;
	 *breaking things for no reason in here ^^
	 */

	cout
			<< "if the intPtr is changed during the ++ or -- the memory location it is pointing to is different "
			<< endl;

	int *intPtr2 = (int*) malloc(sizeof(int) * 10000);

	for (int i = 0; i < 10000; i++) {
		intPtr2[i] = i;
	}

	free(intPtr2);
	intPtr2 = nullptr;

	Pasta* myPasta_c = (Pasta*)malloc(sizeof(Pasta));
	myPasta_c->calories = 100;
	free(myPasta_c);
	myPasta_c = nullptr;

	cout << "arraylistnotes is now ending! goodbye!" << endl; // prints arraylistnotes

	return 0;
}
//key note taking question!
//this is something you should ask!
//do you have a program standardization guide?
