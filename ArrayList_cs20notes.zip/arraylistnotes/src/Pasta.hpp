/*
 * Pasta.hpp
 *
 *  Created on: Sep 14, 2021
 *      Author: andre
 */

#ifndef PASTA_HPP_
#define PASTA_HPP_

class Pasta {
public:
	Pasta();
	virtual ~Pasta();
	int calories;

};

#endif /* PASTA_HPP_ */
