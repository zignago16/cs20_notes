//============================================================================
// Name        : Map_notes_cs20.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <map>

using namespace std;

struct Employee {
private:

public:
	string name;
	int ID;
	double annualSalary;
};
struct Emp {
private:

public:
	string name1;
	int ID1;

};

int main() {

	int employeeID = 0;
	cout << " hello " << endl;

	map<int, Employee*> myEmployeeMap;
	//map<key-data-type, data-data-type> map-name
	//<key-data-type, data-data-type> = a Pair
	// <key-data-type: first
	//< data-data-type: second
	map<int, Employee*>::iterator EIter;

	Employee *anEmployee = new Employee; //emp1
	anEmployee->annualSalary = 150000;
	anEmployee->ID = 9;
	anEmployee->name = "Smith, Stehpanie";

	myEmployeeMap[anEmployee->ID] = anEmployee;

	anEmployee = new Employee;	//emp2
	anEmployee->annualSalary = 10000;
	anEmployee->ID = 12;
	anEmployee->name = "Carlton, Sandy";

	myEmployeeMap[anEmployee->ID] = anEmployee;

	anEmployee = new Employee;	//emp3
	anEmployee->annualSalary = 190000;
	anEmployee->ID = 103;
	anEmployee->name = "Wickham, Avery";

	myEmployeeMap[anEmployee->ID] = anEmployee;

	while (employeeID != -999) {
		cout << "Enter an employeeID (-999 to quit): ";
		cin >> employeeID;
		if (myEmployeeMap[employeeID] != nullptr) {
			cout << myEmployeeMap[employeeID]->name << endl;
		} else {
			cout << " Employee not found! " << endl;
		}	//else
	}	//while

	anEmployee->ID = 540;
	pair<map<int, Employee*>::iterator, bool> insertIT;
	insertIT = myEmployeeMap.insert(make_pair(anEmployee->ID, anEmployee));

	if (insertIT.second == false) {
		cout << "Employee not inserted - already exists" << endl;
	} else {
		cout << "Employee inserted " << endl;
	}	//else

	cout << "cleaning up our pointers" << endl;
	for (EIter = myEmployeeMap.begin(); EIter != myEmployeeMap.end(); ++EIter) {
		delete EIter->second;
	}

/*	cout << "second half of the notes" << endl;
	map<int, Emp*> myEmp;
	map<int, Emp*>::iterator EmpIT;
	pair<map<int, Emp*>::iterator, bool> insterRet;

	if (insterRet.second == false){
		cout << "Error failed to insert" << endl;
	}else{
		cout << "Emp added " << endl;
	}//else
	for(EmpIT = myEmp.begin();
			EmpIT != myEmp.end();
			) */

	cout << "end of maps" << endl; // prints maps
	return 0;
}
