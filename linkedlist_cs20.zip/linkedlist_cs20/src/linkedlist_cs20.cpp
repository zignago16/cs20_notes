//============================================================================
// Name        : linkedlist_cs20.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : linked list notes use for proj
//============================================================================

#include <iostream>
using namespace std;
struct node {
	int data;
	node *next;
};
bool clear (node* &nodePtr);
void printList (node* nodePtr);
node* createnewNode(void);
bool isEmpty(node *nodePtr);
int size(node *nodePtr);
bool push_back(node *&nodePtr, int theData);


int main() {
	cout << "program starting" << endl;

	node *head = nullptr;

	if (isEmpty(head)) {
		cout << "The List is empty" << endl;
	} else {
		cout << "The list is not empty" << endl;
	}//else

	cout << "An empty list contains: " << size(head) << " nodes" << endl;

	push_back(head, 10);

	//if(!push_back(head, 10){
	//	cerr <<
	//}
	if (isEmpty(head)) {
		cout << "The List is empty" << endl;
	} else {
		cout << "The list is not empty" << endl;
	}//else

	cout << "a List with one node contains: " << size(head) << " nodes" <<endl;

	push_back(head, 20);
	if (isEmpty(head)) {
		cout << "The List is empty" << endl;
	} else {
		cout << "The list is not empty" << endl;
	}//else

	cout << "Total nodes in the list: " << size(head) << " nodes" << endl;

	int iterator = rand()%10000;		//TODO: move out of here
	cout << "Total nodes being insterted: " << iterator << endl;
	for( int i=0; i<iterator; i++){
		push_back(head, i);
	}//for
	cout << "Total nodes in the list: " << size(head) << " nodes" << endl;

	printList(head);

	cout << "clearing list" << endl;
	if(clear(head)){
		cout << "list was already cleared" << endl;
	}//if
	else{
		cout << "list is now cleared and is a size of: " << size(head)  << " nodes and is (1 true, 0 false for empty) " << isEmpty(head) << endl;
	}//else

	cout << "program ending..." << endl; // prints linked list notes use for proj
	return 0;
}
bool clear (node* &nodePtr){
	/*
		 * is the nodePtr null?
		 * 			return true
		 * otherwise
		 * 			delete the nodes data(if applicable)
		 * 			save the node's next
		 * 			delete the node
		 * 			Move to the next node
		 * 				end the function
		 * 			otherwise
		 * 				top of the loop
		 *
		 */
	node *tempNode = nodePtr;															//creating tempnode to hold the place in the list
	if  (isEmpty(nodePtr)){
		cout << "List is already empty" << endl;
		return true;
	}//if
	else{

		while(tempNode != nullptr){
			tempNode->data = 0;
			tempNode = nodePtr->next;
			delete nodePtr;
			nodePtr = tempNode;
		}
		return false;
		//TODO: eventually add check to delete to make sure data does not include pointers
	}


} //clear

void printList (node* nodePtr){
	/*
	 * is the nodePtr null?
	 * 			print the list is empty
	 * otherwise
	 * 			create loop that prints and checks
	 * 				print the nodes data
	 * 				move to the next next node
	 * 				is the next node null:
	 * 				end the function
	 * 			otherwise
	 * 				top of the loop
	 *
	 */
	node *tempNode = nodePtr;															//creating tempnode to hold the place in the list
	if (nodePtr == nullptr){															//checking if the current position is nul, could also check using size == 0
		cout <<  "The current list is empty" << endl;									//display the message of the empty list
	}//if																				//
	else{																				//
		while (tempNode->next != nullptr) {												//navigate to the last node while printing the data from each node
			cout << "The current data from the node is: " << tempNode->data << endl; 	// displaying the current node data if not nullptr
					tempNode = tempNode->next;											// moving to the next node
																						//
				}		//while															//
		cout << "The current data from the node is: " << tempNode->data << endl;		//
	}//else



}//printList

//int pop_back(node* nodePtr){
	/*
	 * is the nodePtr null?
	 * 		return false;
	 * TODO: Problem returning an integer
	 * is the nodePtr's next null?
	 * 		save the node's data
	 * 		delete the node
	 * 		set the head to null
	 * 		return the data
	 * otherwise
	 * 		Navigate to the second to last node in the list
	 * 			node->next->next == nullptr
	 * 		save the last node's data ( node-> next->data)
	 * 		delete the node
	 * 		set the current node's next to null
	 * 		return the data
	 */
//}

node* createnewNode(void) {
	node* newNode = nullptr;
	try {
		newNode = new node;		//create the node
	}		//try
	catch (bad_alloc &e) {
		return nullptr;
	}		//catch
	return newNode;
}		//newNode

bool isEmpty(node *nodePtr) {
	if (nodePtr == nullptr) {
		return true;
	} //if
	else {
		return false;
	} //else
} //isEmpty

int size(node *nodePtr) {
	/*
	 * is the list empty?
	 *		yes :return 0
	 * otherwise
	 *		create a loop counter, set it to zero
	 * 		Navigate to the end of the list counting each loop execution
	 * 		return the loop counter
	 */
	unsigned int loopCtr = 0;
	node *tempNode = nodePtr;
	if (isEmpty(nodePtr)) {
		return 0;
	} //if
	else {
		while (tempNode->next != nullptr) {	//navigate to the last node
			tempNode = tempNode->next;		//
			loopCtr++;						//
		}		//while						//
		return ++loopCtr;					//Return the loop counter
	}		//else
}		//size

bool push_back(node *&nodePtr, int theData) {
	//is the list empty
	// *create node
	// *add data
	// point the head to the new node
	// * otherwise
	//create the node
	// navigate to the last node in the list
	// last -> next = new node
	if (isEmpty(nodePtr)) {
		node *newNode = createnewNode();		//create the node
		if(newNode == nullptr){
			return false;
		}//if
		else{}
		newNode->next = nullptr;		//
		newNode->data = theData;		//Add the data
		nodePtr = newNode;				//Set the head to the new node
	}		//if
	else {
		node *newNode = new node;			//create the node
		node *tempNode = nodePtr;			//
		newNode->next = nullptr;			//
		newNode->data = theData;			//Add the data
		while (tempNode->next != nullptr) {	//navigate to the last node
			tempNode = tempNode->next;		//
		}		//while
		tempNode->next = newNode; 			//last->next = new node
	}		//else
			//Todo: Return status of memory allocation
	return true;
}
