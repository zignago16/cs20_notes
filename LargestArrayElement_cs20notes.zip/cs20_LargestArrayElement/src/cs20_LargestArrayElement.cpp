//============================================================================
// Name        : cs20_LargestArrayElement.cpp
// Author      : Andreas Zignago
// Version     :
// Copyright   : school_notes
// Description : Recursion notes on finding the largest number in a array
//============================================================================

#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

const int THESIZE = 1000;

int largestInArray( int intArray[], int arraySize, int largestIndex, int currentIndex){
	/*
	 * Recursively find the largest value in an array
	 * O(n)
	 * Base Case: When you're at the end of the array
	 * General case: Navigate to the next array location after comparing for the largest
	 * Inputs:
	 * 		array address
	 * 		array size
	 * 		largest number's index
	 * 		the current index??
	 * Output:
	 * 		the index of the largest value
	 */
	//is the urrent iterator == the size of the array?
	if(currentIndex == arraySize){
		return largestIndex;
	}
	//otherwise is array[current] < array[current +1]
	else if(intArray[largestIndex] < intArray[currentIndex]){
		largestIndex = currentIndex;
	}
		return largestInArray(intArray, arraySize, largestIndex, currentIndex+1);
}

int main() {



	int theArray[THESIZE];
	int theLargestFound = 0;

	srand(time(0));

	for(int i=0; i<THESIZE; i++){
		theArray[i] = rand()%25000;
	}

	theLargestFound = largestInArray(theArray, THESIZE, 0, 0);
	cout << "The largest found was: " << theArray[theLargestFound] << endl;

	theLargestFound = 0;

	for (int i =0; i < THESIZE; i++){
		if(theArray[i] > theArray[theLargestFound]){
			theLargestFound = i;
		}
		else{}
	}
	cout << "The largest found in loop: " << theArray[theLargestFound] << endl;


	cout << "Program ending" << endl; // prints Recursion notes on finding the largest number in a array
	return 0;
}
